package mx.uam.is.practicadiseno.negocio;

public interface Observador {

	/**
	 * Se le notifica al observador de un cambio de estado
	 *
	 */
	public void actualiza();

}
