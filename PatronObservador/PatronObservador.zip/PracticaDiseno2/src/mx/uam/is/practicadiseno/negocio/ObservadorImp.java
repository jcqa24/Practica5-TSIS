package mx.uam.is.practicadiseno.negocio;



public class ObservadorImp implements Observador {
	
	@Override
	public void actualiza() {
		this.actualiza();
	}

}
